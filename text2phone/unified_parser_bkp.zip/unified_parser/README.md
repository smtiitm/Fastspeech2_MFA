Run from inside this folder.

./run.sh <input-file> <output-file>


